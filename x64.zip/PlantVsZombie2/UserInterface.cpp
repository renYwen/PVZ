#include "UserInterface.h"
#include "Controller.h"
#include "GameStatics.h"
#include "Camera.h"


extern set<Widget*>GamePainters{};

extern set<UserInterface*>GameUIs{};

extern vector<UserInterface*>GameUIs_{};


/* Characters */

map<string, COLORREF>Characters::TextColorMap = 
{ {"$0",WHITE}/*��ɫ*/,{"$1",RGB(245, 245, 245)}/*�̰�ɫ*/,
	{"$2",LIGHTGRAY}/*ǳ��ɫ*/,{"$3",DARKGRAY}/*���ɫ*/, {"$4",BLACK}/*��ɫ*/,
	{"$5",GREEN}/*����ɫ*/,{"$6",LIGHTGREEN}/*��ɫ*/, {"$7",YELLOW}/*��ɫ*/,
	{"$8",RGB(255, 165, 0)}/*��ɫ*/,{"$9",LIGHTRED}/*ǳ��ɫ*/, {"$a",RED}/*���ɫ*/,
	{"$b",LIGHTMAGENTA}/*��ɫ*/,{"$c",MAGENTA}/*Ʒ��ɫ*/, {"$d",RGB(148, 0, 211)}/*��ɫ*/,
	{"$e",BLUE}/*����ɫ*/,{"$f",LIGHTBLUE}/*����ɫ*/, {"$g",LIGHTCYAN}/*����ɫ*/,
	{"$h",CYAN}/*��ɫ*/,{"$i",BROWN}/*��ɫ*/
};

void Characters::SetText(string te, int si, LPCTSTR ty)
{
	row = 1; column = 0;
	int temp = 0;
	for (int i = 0; i < te.size(); ++i) {
		if (te[i] == '\n') { row++, column = temp > column ? temp : column, temp = 0; }
		else if (te[i] == '$')
		{
			if (i + 1 < te.size()) {
				string buf = "$"; buf += te[i + 1];
				if (TextColorMap.find(buf) != TextColorMap.end())++i;
				else ++temp;
			}
			else ++temp;
		}
		else ++temp;
	}
	column = temp > column ? temp : column;
	texts = te;
	size = si;
	type = ty;
}

void Characters::PrintText(Vector pos, int pattern)
{
	settextstyle(6 * size, 3 * size, type);
	COLORREF color = BLACK;
	settextcolor(color);
	string temp;
	int r = 0;

	for (int i = 0; i < texts.size(); ++i) {
		if (texts[i] == '\n')
		{
			outtextxy((int)pos.x + (GetWidth() - (int)temp.size() * 3 * size) * pattern / 2,
				(int)pos.y + r * 6 * size, temp.c_str());
			temp.clear(), ++r;
		}
		else if (texts[i] == '$')
		{
			if (i + 1 < texts.size()) {
				string buf = "$"; buf += texts[i + 1];
				if (TextColorMap.find(buf) != TextColorMap.end())
				{
					color = (*TextColorMap.find(buf)).second;
					settextcolor(color);
					i++;
				}
				else temp.push_back(texts[i]);
			}
			else temp.push_back(texts[i]);
		}
		else {
			temp.push_back(texts[i]);
		}
	}
	outtextxy((int)pos.x + (GetWidth() - (int)temp.size() * 3 * size) * pattern / 2,
		(int)pos.y + r * 6 * size, temp.c_str());
	settextcolor(BLACK);
}







/* UIRenderer */

void UIRenderer::SetScale(Vector scale)
{
	if (copy)delete copy; copy = new IMAGE;
	loadimage(copy, sprite.name.c_str(), scale.x, scale.y);
	sprite.image = copy;
}

void UIRenderer::Render()
{
	if (sprite.image) {
		Vector pos =  GetLocalPosition() + sprite.delta;


		if (bEn) {
			putimage(pos.x, pos.y, en, SRCPAINT);
			putimage(pos.x, pos.y, sprite.image, SRCAND);
			return;
		}//��Ԫ��դ

		HDC dstDC = GetImageHDC(NULL);
		HDC srcDC; int w, h;
		if ((transform.rotation == 0 && !filter) || !copy) {
			srcDC = GetImageHDC(sprite.image);
			w = sprite.image->getwidth();
			h = sprite.image->getheight();
		}
		else {
			srcDC = GetImageHDC(copy);
			w = copy->getwidth();
			h = copy->getheight();
		}//��ת����

		BLENDFUNCTION bf = { AC_SRC_OVER, 0, transparency, AC_SRC_ALPHA };

		if (sprite_.isUsed)
			AlphaBlend(dstDC, int(pos.x), int(pos.y), sprite_.aimSize.x, sprite_.aimSize.y,
				srcDC, sprite_.aimLoc.x, sprite_.aimLoc.y, sprite_.aimSize.x, sprite_.aimSize.y, bf);
		else AlphaBlend(dstDC, int(pos.x), int(pos.y), w, h, srcDC, 0, 0, w, h, bf);
	}
}



/* Widget */

void Widget::ShowInfoBox()
{
	if (IsUnderCursor() && bInfoBox) {
		setlinecolor(BLACK);
		setlinestyle(PS_SOLID | PS_JOIN_BEVEL);
		setfillcolor(RGB(255, 247, 213));

		Vector pos = MainController->GetCursorScreenPosition() + Vector(-15, 15);
		fillrectangle(pos.x, pos.y, pos.x + InfoText.GetWidth(), pos.y + InfoText.GetHeight());
		InfoText.PrintText(pos, 1);
	}
}

bool Widget::IsUnderCursor()
{
	float x = MainController->GetCursorScreenPosition().x;
	float y = MainController->GetCursorScreenPosition().y;
	Vector loc = GetAbsoluteLocation();
	if (x<size.x + loc.x && x> loc.x && y<size.y + loc.y && y> loc.y)
	{
		return true;
	}
	return false;
}




/* Image */

Image::Image()
{
	ima = GameStatics::ConstructComponent<UIRenderer>(Vector(0,0));
	ui = new IMAGE;
	ima->SetImage(ui);
}

Image::~Image()
{
	GameComponents_.insert(static_cast<Component*>(ima));
	delete ui;
}

void Image::Update()
{
	Widget::Update(); ima->SetPosition(GetAbsoluteLocation());
}

void Image::SetVisibility(bool visible)
{
	bVisibiliy = visible;
	if (visible) { GameRenders.insert(ima); ima->SetPosition(GetAbsoluteLocation());}
	else GameRenders.erase(ima);
}

void Image::LoadPicture(string path, Vector si)
{
	Vector temp = (si == Vector(0, 0) ? GetSize() : si);
	ima->Load(path, temp.x, temp.y); ima->SetLayer(layer);
}

void Image::LoadPicture(string path, string path_en, Vector si)
{
	Vector temp = (si == Vector(0, 0) ? GetSize() : si);
	ima->Load_(path, path_en,temp.x, temp.y); ima->SetLayer(layer);
}

void Image::SetLayer(int lay)
{
	layer = lay;  if(ima)ima->SetLayer(layer);
}

BYTE Image::GetTrans()
{
	return ima->GetTransparency();
}

void Image::SetTrans(int tran)
{
	if (ima)ima->SetTransparency(tran);
}

void Image::SetPicSize(Vector si)
{
	ima->SetFixSize(si);
}

void Image::SetPicLoc(Vector loc)
{
	ima->SetFixLoc(loc);
}

void Image::SetScale(Vector scale)
{
	ima->SetScale(scale);
}

void Image::SetRotation(float rot)
{
	ima->SetRotation(rot);
}

void Image::AddRotation(float rot)
{
	ima->AddRotation(rot);
}

void Image::RotateAround(Vector center, float angle)
{
	double radian = PI * angle / 180;
	float fSin = (float)sin(-radian), fCos = (float)cos(-radian);			

	Vector relLoc = GetAbsoluteLocation() - center;

	SetLocation(Vector(relLoc.x * fCos - relLoc.y * fSin,
		relLoc.x * fSin + relLoc.y * fCos) + center - parent->GetAbsoluteLocation());
	AddRotation(angle);
}

float Image::GetRotation()
{
	return ima->GetLocalRotation();
}

bool Image::IsCursorOn()
{
	return bVisibiliy && IsUnderCursor();
}





/* Button */

Button::Button()
{
	normal.image = new IMAGE;
	hover.image = new IMAGE;
	click.image = new IMAGE;
}

Button::~Button()
{
	delete normal.image;
	delete hover.image;
	delete click.image;
}

void Button::Update()
{
	Image::Update();
	if (IsCursorClicked())ima->SetSprite(click);
	else if (IsCursorOn())ima->SetSprite(hover);
	else ima->SetSprite(normal);

	if (IsCursorClicked())clickFlag = 1;
	else if (clickFlag == 1) clickFlag = 2 - MainController->GetCursorMessage().lbutton;
	else clickFlag = 0;
}

void Button::LoadPicture(string path, Vector si)
{
	Vector temp = (si == Vector(0, 0) ? GetSize() : si);
	ima->SetLayer(layer);
	loadimage(normal.image, LPCTSTR(path.c_str()), temp.x, temp.y);
}

void Button::LoadHoverPicture(string path, Vector si)
{
	Vector temp = (si == Vector(0, 0) ? GetSize() : si); 
	ima->SetLayer(layer);
	loadimage(hover.image, LPCTSTR(path.c_str()), temp.x, temp.y);
}

void Button::LoadClickPicture(string path, Vector si)
{
	Vector temp = (si == Vector(0, 0) ? GetSize() : si); 
	ima->SetLayer(layer);
	loadimage(click.image, LPCTSTR(path.c_str()), temp.x, temp.y);
}

bool Button::IsCursorClicked()
{
	return bVisibiliy && IsUnderCursor() && MainController->GetCursorMessage().lbutton;
}

bool Button::IsCursorUp()
{
	return bVisibiliy && clickFlag == 2;
}

