#include "MultiThreadMediaPlayer.h"

extern __MultiThreadMediaPlayer MCI{};