#pragma once
#include"CoreMinimal.h"


class GameInstance
{
public:
	GameInstance();

};