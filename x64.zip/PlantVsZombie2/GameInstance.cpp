#include "GameInstance.h"

extern GameInstance* GlobalInstance{};

GameInstance::GameInstance()
{

}
