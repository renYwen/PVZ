#pragma once
#include "BoxCollider.h"


//��ҿ�������
class Controller :public Object
{
protected:
	bool bEnabled = true;

	ExMessage msg{};
public:

	virtual void Update() { if (logPattern && msg.lbutton)cout<<GetCursorScreenPosition()<<" "; }

	void PeekInfo() { if(bEnabled)peekmessage(&msg); }
	
	const ExMessage& GetCursorMessage() { return msg; }

	Vector GetCursorWorldPosition();
	
	Vector GetCursorScreenPosition() { return Vector(msg.x, msg.y); }

	void SetPossession(){MainController = this;}

	void SetEnabled(bool enable) { bEnabled = enable; }

	bool BoxJudgeUnderCursor(BoxCollider* another);

	vector<Object*>GetObjectsUnderCursor();//����õĶ����������ײ��

	template<class T>
	T* GetObjectUnderCursor();//����õĶ����������ײ��

};

template<class T>
T* Controller::GetObjectUnderCursor()
{
	for (auto it = GameColliders.begin(); it != GameColliders.end(); ++it)
	{
		if (BoxJudgeUnderCursor(*it))
			if (T* aim = Cast<T>((*it)->GetOwner()))return aim;
	}
}